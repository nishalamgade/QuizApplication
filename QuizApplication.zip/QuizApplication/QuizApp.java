import java.util.*;

class Question {
    private String questionText;
    private List<String> options;
    private int correctOption;

    public Question(String questionText, List<String> options, int correctOption) {
        this.questionText = questionText;
        this.options = new ArrayList<>(options);
        this.correctOption = correctOption - 1; // Convert to 0-based index
    }

    public String getQuestionText() {
        return questionText;
    }

    public List<String> getOptions() {
        return options;
    }

    public int getCorrectOption() {
        return correctOption;
    }

    public void shuffleOptions() {
        String correctAnswer = options.get(correctOption);
        Collections.shuffle(options);
        correctOption = options.indexOf(correctAnswer); // Update correctOption to the new position
    }
}

public class QuizApp {

    private static List<Question> questions = new ArrayList<>();
    private static int score = 0;

    public static void main(String[] args) {
        setupQuestions();
        shuffleQuestions();
        runQuiz();
        displayResults();
    }

    private static void setupQuestions() {
        questions.add(new Question(
                "What is the time complexity of binary search?",
                Arrays.asList("O(n)", "O(log n)", "O(n^2)", "O(1)"),
                2
        ));
        questions.add(new Question(
                "Which of the following is not an OOP principle?",
                Arrays.asList("Encapsulation", "Inheritance", "Polymorphism", "Compilation"),
                4
        ));
        questions.add(new Question(
                "What does JVM stand for?",
                Arrays.asList("Java Virtual Machine", "Java Visual Machine", "Java Verification Machine", "Java Version Machine"),
                1
        ));
        questions.add(new Question(
                "Which data structure is used for LIFO operations?",
                Arrays.asList("Queue", "Stack", "Linked List", "Tree"),
                2
        ));
        questions.add(new Question(
                "What is the default value of a boolean in Java?",
                Arrays.asList("true", "false", "null", "0"),
                2
        ));
        questions.add(new Question(
                "What is the main feature of a linked list?",
                Arrays.asList("Fixed size", "Dynamic size", "Easy sorting", "Random access"),
                2
        ));
        questions.add(new Question(
                "What does HTTP stand for?",
                Arrays.asList("Hypertext Transfer Protocol", "Hyper Transfer Text Protocol", "Hyperlink Transfer Protocol", "Hyper Text Transmission Protocol"),
                1
        ));
        questions.add(new Question(
                "Which layer of the OSI model is responsible for routing?",
                Arrays.asList("Physical", "Data Link", "Network", "Transport"),
                3
        ));
        questions.add(new Question(
                "Which sorting algorithm has the best average-case time complexity?",
                Arrays.asList("Bubble Sort", "Quick Sort", "Merge Sort", "Selection Sort"),
                3
        ));
        questions.add(new Question(
                "What is the full form of SQL?",
                Arrays.asList("Structured Query Language", "Sequential Query Language", "Simple Query Language", "Standard Query Language"),
                1
        ));
        questions.add(new Question(
                "Which protocol is used to secure communication over the internet?",
                Arrays.asList("HTTP", "FTP", "HTTPS", "SMTP"),
                3
        ));
        questions.add(new Question(
                "What is the main purpose of DNS?",
                Arrays.asList("Routing packets", "Translating domain names to IP addresses", "Encrypting data", "Caching web pages"),
                2
        ));
        questions.add(new Question(
                "Which language is primarily used for Android app development?",
                Arrays.asList("Python", "Java", "Swift", "Kotlin"),
                4
        ));
        questions.add(new Question(
                "What is the key advantage of using recursion?",
                Arrays.asList("Faster computation", "Simplified code", "Reduced memory usage", "Easy debugging"),
                2
        ));
        questions.add(new Question(
                "What does TCP stand for?",
                Arrays.asList("Transmission Control Protocol", "Transfer Control Protocol", "Transport Communication Protocol", "Transfer Communication Protocol"),
                1
        ));
        questions.add(new Question(
                "Which keyword is used to inherit a class in Java?",
                Arrays.asList("extends", "implements", "inherit", "class"),
                1
        ));
        questions.add(new Question(
                "Which is not a type of NoSQL database?",
                Arrays.asList("Document", "Relational", "Key-Value", "Graph"),
                2
        ));
        questions.add(new Question(
                "What is the smallest unit of data in a computer?",
                Arrays.asList("Byte", "Bit", "Nibble", "Word"),
                2
        ));
        questions.add(new Question(
                "Which algorithm is used in public key encryption?",
                Arrays.asList("AES", "RSA", "MD5", "SHA"),
                2
        ));
        questions.add(new Question(
                "What is the default port number for HTTP?",
                Arrays.asList("80", "8080", "443", "21"),
                1
        ));
        questions.add(new Question(
                "Which Java collection does not allow duplicate elements?",
                Arrays.asList("List", "Set", "Map", "Queue"),
                2
        ));
        questions.add(new Question(
                "Which operating system is open-source?",
                Arrays.asList("Windows", "macOS", "Linux", "Solaris"),
                3
        ));
        questions.add(new Question(
                "Which structure is used to implement BFS?",
                Arrays.asList("Stack", "Queue", "Heap", "Tree"),
                2
        ));
        questions.add(new Question(
                "Which tag is used for writing JavaScript in an HTML document?",
                Arrays.asList("<script>", "<js>", "<javascript>", "<code>"),
                1
        ));
        questions.add(new Question(
                "What is a deadlock in an operating system?",
                Arrays.asList("A situation where processes run simultaneously", "A condition where processes block each other", "A state of high CPU usage", "A situation of infinite loop"),
                2
        ));
    }

    private static void shuffleQuestions() {
        Collections.shuffle(questions);
        for (Question question : questions) {
            question.shuffleOptions();
        }
    }

    private static void runQuiz() {
        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);

            System.out.println("Question " + (i + 1) + ": " + question.getQuestionText());
            List<String> options = question.getOptions();
            for (int j = 0; j < options.size(); j++) {
                System.out.println((j + 1) + ". " + options.get(j));
            }
            System.out.print("Enter your choice (1-4): ");

            int userAnswer = scanner.nextInt() - 1; // Convert to 0-based index

            if (userAnswer == question.getCorrectOption()) {
                System.out.println("Correct!\n");
                score++;
            } else {
                System.out.println("Wrong! The correct answer was " + (question.getCorrectOption() + 1) + ".\n");
            }
        }

        scanner.close();
    }

    private static void displayResults() {
        System.out.println("\nQuiz Over!");
        System.out.println("Your score: " + score + " out of " + questions.size());

        double percentage = ((double) score / questions.size()) * 100;
        System.out.println("You scored " + percentage + "%.\n");

        if (percentage == 100) {
            System.out.println("Congratulations! You scored full marks!");
        } else if (percentage >= 75) {
            System.out.println("Excellent performance!");
        } else if (percentage >= 50) {
            System.out.println("Good job! Keep practicing.");
        } else if (percentage >= 30) {
            System.out.println("Fair effort, but there's room for improvement.");
        } else {
            System.out.println("You need to work harder. Don't give up!");
        }
    }
}
